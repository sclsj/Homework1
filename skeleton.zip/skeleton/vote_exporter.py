import lxml
import lxml.etree
import os

# Get lxml with 'pip3 install lxml'

# Now using wget to fetch the file, because the government website blocks bare downloads using urllib
url = "https://www.senate.gov/legislative/LIS/roll_call_votes/vote1171/vote_117_1_00001.xml"
os.system("wget " + url)

# Use fromstring() instead of parse() if you have a string object
tree = lxml.etree.parse("vote_117_1_00001.xml")

members = tree.xpath("//member")

for member in members:
	member_full = member.xpath("member_full")[0].text
	vote_cast = member.xpath('vote_cast')[0].text

	print(member_full + " voted " + vote_cast)
