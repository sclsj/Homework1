-- Your file should drop the SenatorVotes schema, in case it exists,
-- then create the SenatorVotes schema, and finally use that schema.

-- After that, your file should contain the CREATE TABLE statements
-- to insert the tables into your relation.
