import os
import glob
import lxml
import lxml.etree
import datetime

# I want the votes stored as 'Y', 'N', or 'A'. This might be useful.
def convertVoteCast(vote_cast):
	if vote_cast == 'Yea':
		return 'Y'

	if vote_cast == 'Nay':
		return 'N'
	
	return 'A'

# This converts the date obtained from the XML files into a SQL date string. This might be useful.
def convertDate(date):
	date_split = date.split(',')
	day = date_split[0] + date_split[1]

	return datetime.datetime.strptime(day, '%B %d %Y').strftime('%Y-%m-%d')

# Use helper functions. Add other parameters as appropriate.

def insertVoteCast(cursor, other_params):
	pass

def insertVote(cursor, other_params):
	pass

def insertSenator(cursor, other_params):
	pass

# Read the 'Schema.sql' file into the 'schema_string' variable
# See 'Schema.sql' for comments on what that file should contain
schema_string = ""

# Connect to MySQL

# Run the contents of 'Schema.sql', creating a schema (deleting previous incarnations),
# and creating the three relations mentioned in the handout.

# Because 'Schema.sql' is a multi-line SQL file, you may find the multi=True
# parameter to execute necessary.
#
# ... (code) ...
# ... cursor.execute(schema_string, multi=True)
# ... (code) ...

# After running the contents of 'Schema.sql', you have to do again
# a USE SenatorVotes in your connection before adding the tuples.

for filename in glob.glob("XML/*.xml"):
	# Create the parsing tree using lxml (we did it in class and you have example files)

	# Extract the attributes of Vote 

	insertVote(cursor, other_attributes)

	# Find all members

	for member in members:
		# Identify a senator

		# IF senator not seen before
			# Parse other attributes of senator
			insertSenator(cursor, other_attributes)

		insertVoteCast(cursor, other_atributes)

# Don't forget to commit, close connections, etc
